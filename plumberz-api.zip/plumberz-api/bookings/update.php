<?php
include '../connection.php';
include '../auth_check.php';


if($_POST){
	$sql = "update `bookings` set name='{$_POST['name']}', email='{$_POST['email']}',service_name='{$_POST['service_name']}',service_date='{$_POST['service_date']}',special_request='{$_POST['special_request']}' where id='{$_POST['id']}'";
	
	$result=$db->query($sql);
	if($result)
		echo json_encode(array("message" => "Successful updated."));
	else
		echo json_encode(array("message" => "Failed."));
	
}

