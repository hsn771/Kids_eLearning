<?php 
include '../connection.php';
include '../auth_check.php';

if($_POST){
	if($_POST['name'] && $_POST['email']){
		$sql = "insert into `bookings` set name='{$_POST['name']}', email='{$_POST['email']}', special_request='{$_POST['special_request']}', service_date='{$_POST['service_date']}',service_name='{$_POST['service_name']}'";
		
		$result=$db->query($sql);
		if($result)
			echo json_encode(array("message" => "Successful saved.",'error'=>0));
		else
			echo json_encode(array("message" => "Failed.",'error'=>1));
	}else{
		echo json_encode(array("message" => "Name, email and password are required.",'error'=>1));
	}
}

