<?php
include '../connection.php';
include '../auth_check.php';


if($_POST){
	$sql = "update `appointment` set g_name='{$_POST['g_name']}', g_email='{$_POST['g_email']}',c_name='{$_POST['c_name']}',c_age='{$_POST['c_age']}',msg='{$_POST['msg']}' where id='{$_POST['id']}'";
	
	$result=$db->query($sql);
	if($result)
		echo json_encode(array("message" => "Successful updated."));
	else
		echo json_encode(array("message" => "Failed."));
	
}

