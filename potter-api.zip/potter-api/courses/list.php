<?php
include '../connection.php';
include '../auth_check.php';
$data = [];

$sql = "SELECT courses.*,categories.name as cat_name,teacher.tname FROM `courses` left JOIN categories on categories.id=courses.category_id left JOIN teacher on teacher.id=courses.teacher_id ";
$result=$db->query($sql);
while($row = $result->fetch_object()){
	$data[]= $row;
}
echo json_encode($data); 