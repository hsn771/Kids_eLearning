<?php
include '../connection.php';
include '../auth_check.php';

$uploadDir = '../';
$image = ""; // default empty string

if (!empty($_FILES['files']['tmp_name'][0])) { // check if file is uploaded
    foreach ($_FILES['files']['tmp_name'] as $index => $tmpName) {
        $name = rand() . basename($_FILES['files']['name'][$index]);
        $targetPath = 'teacher_file/' . $name;

        if (move_uploaded_file($tmpName, $uploadDir . $targetPath)) {
            $image = ", timage='" . $db->real_escape_string($targetPath) . "'";
        }
    }
}

if (!empty($_POST['id']) && !empty($_POST['tname']) && !empty($_POST['tpost'])) {
    $tname = $db->real_escape_string($_POST['tname']);
    $tpost = $db->real_escape_string($_POST['tpost']);
    $id    = $db->real_escape_string($_POST['id']);

    $sql = "UPDATE `teacher` 
            SET tname='$tname', 
                tpost='$tpost' 
                $image
            WHERE id='$id'";

    $result = $db->query($sql);

    if ($result) {
        echo json_encode(array("message" => "Successfully updated.", "error" => 0));
    } else {
        echo json_encode(array("message" => "Failed.", "error" => 1));
    }
} else {
    echo json_encode(array("message" => "Missing required fields.", "error" => 1));
}
