<?php
include '../connection.php';
include '../auth_check.php';

$uploadDir = '../teacher_file/';
$imagePath = '';

if (!empty($_FILES['files']['tmp_name'][0])) {
    foreach ($_FILES['files']['tmp_name'] as $index => $tmpName) {
        $name = rand() . '_' . basename($_FILES['files']['name'][$index]);
        $fullPath = $uploadDir . $name;

        if (move_uploaded_file($tmpName, $fullPath)) {
            $imagePath = 'teacher_file/' . $name; // save relative path in DB
        } else {
            echo json_encode(array("message" => "File upload failed.", 'error' => 1));
            exit;
        }
    }
}

if (!empty($_POST['tname'])) {
    $tname = $db->real_escape_string($_POST['tname']);
    $tpost = $db->real_escape_string($_POST['tpost']);

    $sql = "INSERT INTO `teacher` (tname, tpost, timage) 
            VALUES ('$tname', '$tpost', '$imagePath')";

    if ($db->query($sql)) {
        echo json_encode(array("message" => "Successfully saved.", 'error' => 0));
    } else {
        echo json_encode(array("message" => "Database insert failed.", 'error' => 1));
    }
} else {
    echo json_encode(array("message" => "Name is required.", 'error' => 1));
}
