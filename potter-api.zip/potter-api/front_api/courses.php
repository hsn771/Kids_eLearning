<?php
include '../connection.php';

$data = [];

$sql = "SELECT courses.*,categories.name as cat_name, teacher.tname,teacher.tpost,teacher.timage FROM `courses`
			 JOIN categories on categories.id=courses.category_id
			 JOIN teacher on teacher.id=courses.teacher_id
			 ";
$result=$db->query($sql);
while($row = $result->fetch_object()){
	$data[]= $row;
}
echo json_encode($data); 