<?php
	include '../connection.php';
	$data = [];
	$sql="insert into orders set order_date=now(), ";
	if($_POST){
		foreach($_POST as $k=>$v){
			$v=$db->real_escape_string($v);
			$sql.=" $k='$v',";
		}
	}
	$sql=rtrim($sql,',');
// echo $sql;
// die();
	$result=$db->query($sql);
	$id=mysqli_insert_id($db);
	if($result)
		echo json_encode(array("message" => "Successful saved.",'error'=>0,'order_id'=>$id));//important for invoice according to order_id
	else
		echo json_encode(array("message" => "Failed.",'error'=>1));
	
