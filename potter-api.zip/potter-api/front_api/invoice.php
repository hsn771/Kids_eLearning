<?php 
include '../connection.php';

if (!isset($_GET['order_id'])) {
    echo json_encode(["error" => 1, "message" => "Order ID is required"]);
    exit;
}

$order_id = intval($_GET['order_id']);

// Get order data
$orderQuery = $conn->prepare("SELECT * FROM orders WHERE order_id = ?");
$orderQuery->bind_param("i", $order_id);
$orderQuery->execute();
$orderResult = $orderQuery->get_result();

if ($orderResult->num_rows === 0) {
    echo json_encode(["error" => 1, "message" => "Invoice not found"]);
    exit;
}

$order = $orderResult->fetch_assoc();

// Get cart items (assuming stored as JSON in DB)
$items = [];
if (!empty($order['cart_details'])) {
    $items = json_decode($order['cart_details'], true);
}

// Final output
$response = [
    "order_id" => $order['order_id'],
    "customer_name" => $order['customer_name'],
    "grand_total" => $order['grand_total'],
    "creation_date" => $order['created_at'], // Assuming you have this field
    "status" => $order['status'] ?? 'Unpaid', // Optional
    "items" => $items
];

echo json_encode($response);
?>
