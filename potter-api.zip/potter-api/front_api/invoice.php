<?php 
// Include connection with correct path
include __DIR__ . '/../connection.php';

// Set content type to JSON
header('Content-Type: application/json');

// Check if database connection is established
if (!isset($db) || $db->connect_error) {
    echo json_encode(["error" => 1, "message" => "Database connection failed"]);
    exit;
}

if (!isset($_GET['order_id'])) {
    echo json_encode(["error" => 1, "message" => "Order ID is required"]);
    exit;
}

$order_id = intval($_GET['order_id']);

// Get order data - using 'id' column instead of 'order_id'
$orderQuery = $db->prepare("SELECT * FROM orders WHERE id = ?");
$orderQuery->bind_param("i", $order_id);
$orderQuery->execute();
$orderResult = $orderQuery->get_result();

if ($orderResult->num_rows === 0) {
    echo json_encode(["error" => 1, "message" => "Invoice not found for ID: " . $order_id]);
    exit;
}

$order = $orderResult->fetch_assoc();

// Get cart items from JSON field
$items = [];
if (!empty($order['cart_details']) && $order['cart_details'] != '[]') {
    $items = json_decode($order['cart_details'], true);
}

// Determine status text
$statusText = 'Pending';
if ($order['order_status'] == 1) {
    $statusText = 'Accepted';
} elseif ($order['order_status'] == 2) {
    $statusText = 'Delivered/Completed';
} elseif ($order['order_status'] == 3) {
    $statusText = 'Cancelled';
}

// Final output
$response = [
    "error" => 0,
    "message" => "Success",
    "id" => $order['id'], // Using 'id' instead of 'order_id'
    "customer_name" => $order['customer_name'],
    "customer_email" => $order['customer_email'],
    "customer_contact" => $order['customer_contact'],
    "billing_address" => $order['billing_address'],
    "grand_total" => $order['grand_total'],
    "sub_total" => $order['sub_total'],
    "discount" => $order['discount'],
    "creation_date" => $order['created_at'],
    "status" => $statusText,
    "items" => $items
];

echo json_encode($response);
?>